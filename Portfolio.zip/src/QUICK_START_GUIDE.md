# 🚀 Quick Start Guide - Farheen Portfolio

## ⚡ 5-Minute Setup

### Step 1: Install Node.js
1. Go to https://nodejs.org/
2. Download and install the LTS version
3. Restart your computer after installation

### Step 2: Open in VS Code
1. Download and extract the portfolio folder
2. Open VS Code
3. Click **File** → **Open Folder**
4. Select the portfolio folder

### Step 3: Install Dependencies
1. Open Terminal in VS Code: **Terminal** → **New Terminal** (or press `` Ctrl+` ``)
2. Type and press Enter:
   ```bash
   npm install
   ```
3. Wait 2-5 minutes for installation to complete

### Step 4: Run the Portfolio
1. In the same terminal, type:
   ```bash
   npm run dev
   ```
2. You'll see a message with a local URL (like `http://localhost:5173`)
3. **Ctrl+Click** on the URL or open it in your browser

### Step 5: Done! 🎉
Your portfolio is now running! You should see:
- Beautiful 3D animated homepage
- Your name and information
- Smooth scrolling sections
- Interactive contact form

---

## 🎨 Quick Customization

### Change Your Photo
1. Open `/src/components/Hero.tsx`
2. Find line with `ImageWithFallback`
3. Replace the `src` URL with your photo URL or local path

### Update Your Name & Info
1. Open `/src/components/Hero.tsx`
2. Change the text in the `<h1>` and `<h2>` tags
3. Update email, phone, and social links

### Add Your CV
1. Put your CV PDF in the `/public` folder
2. Open `/src/components/Hero.tsx`
3. Find "Download CV" button
4. Update the file path

---

## ❓ Troubleshooting

**Problem: npm install fails**
- Delete `node_modules` folder
- Delete `package-lock.json` file
- Run `npm install` again

**Problem: Port already in use**
- Close any other running development servers
- Or use: `npm run dev -- --port 3000`

**Problem: Blank white screen**
- Check terminal for errors
- Make sure all files are in the correct folders
- Try `npm install` again

---

## 📞 Need Help?

- Check the full **SETUP_INSTRUCTIONS.md** file
- Read the **README.md** for detailed documentation
- Email: farheendeshmukh38@gmail.com

---

**Happy Coding! 💻✨**
