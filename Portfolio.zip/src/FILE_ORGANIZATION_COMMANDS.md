# 📋 File Organization - Complete Command List

## ⚠️ IMPORTANT: Read This First!

Your current structure has files in the **WRONG** locations. To make your portfolio work in VS Code, you need to reorganize the files.

## Current Issues:
- Components are in `/components/` but should be in `/src/components/`
- Styles are in `/styles/` but should be in `/src/styles/`
- You have TWO App.tsx files (one in root, one in /src)

## 🎯 Solution: Follow These Steps

### Method 1: Using VS Code (Recommended - Easy!)

1. **Open VS Code**
2. **Open your portfolio folder** in VS Code

3. **Create the correct folder structure:**
   - Right-click in the file explorer
   - Select "New Folder"
   - Create: `src/components/ui`
   - Create: `src/components/figma`
   - Create: `src/styles`

4. **Move files by dragging:**

   **STEP A: Move main components**
   - Select ALL files in `/components/` folder (NOT the ui or figma subfolders)
   - Drag them to `/src/components/`
   - Files to move:
     - About.tsx
     - Contact.tsx
     - Experience.tsx
     - Footer.tsx
     - Hero.tsx
     - Navigation.tsx
     - Projects.tsx
     - Skills.tsx

   **STEP B: Move UI components**
   - Select ALL files in `/components/ui/` folder
   - Drag them to `/src/components/ui/`

   **STEP C: Move figma component**
   - Select `ImageWithFallback.tsx` from `/components/figma/`
   - Drag it to `/src/components/figma/`

   **STEP D: Move styles**
   - Select `globals.css` from `/styles/`
   - Drag it to `/src/styles/`

5. **Delete old folders:**
   - Right-click `/components/` folder → Delete
   - Right-click `/styles/` folder → Delete
   - Right-click `/App.tsx` (the one in ROOT, NOT in /src) → Delete

6. **DONE!** ✅

---

### Method 2: Using Terminal Commands

**For Mac/Linux:**

```bash
# Navigate to your project folder
cd /path/to/farheen-portfolio

# Create src folder structure
mkdir -p src/components/ui
mkdir -p src/components/figma
mkdir -p src/styles

# Move component files
cp components/*.tsx src/components/
cp components/ui/* src/components/ui/
cp components/figma/* src/components/figma/
cp styles/globals.css src/styles/

# Delete old folders
rm -rf components
rm -rf styles
rm App.tsx

echo "✅ Files reorganized successfully!"
```

**For Windows PowerShell:**

```powershell
# Navigate to your project folder
cd C:\path\to\farheen-portfolio

# Create src folder structure
New-Item -ItemType Directory -Force -Path src\components\ui
New-Item -ItemType Directory -Force -Path src\components\figma
New-Item -ItemType Directory -Force -Path src\styles

# Move component files
Copy-Item -Path components\*.tsx -Destination src\components\
Copy-Item -Path components\ui\* -Destination src\components\ui\
Copy-Item -Path components\figma\* -Destination src\components\figma\
Copy-Item -Path styles\globals.css -Destination src\styles\

# Delete old folders and file
Remove-Item -Recurse -Force components
Remove-Item -Recurse -Force styles
Remove-Item -Force App.tsx

Write-Host "✅ Files reorganized successfully!"
```

**For Windows Command Prompt:**

```cmd
REM Navigate to your project folder
cd C:\path\to\farheen-portfolio

REM Create folders manually in File Explorer or use:
mkdir src\components\ui
mkdir src\components\figma
mkdir src\styles

REM Then manually copy files using File Explorer
REM Delete old folders using File Explorer
```

---

## ✅ After Reorganization, Your Structure Should Look Like:

```
farheen-portfolio/
├── public/
├── src/
│   ├── main.tsx                    ✓ (already there)
│   ├── App.tsx                     ✓ (already there)
│   ├── components/
│   │   ├── About.tsx               ← MOVED HERE
│   │   ├── Contact.tsx             ← MOVED HERE
│   │   ├── Experience.tsx          ← MOVED HERE
│   │   ├── Footer.tsx              ← MOVED HERE
│   │   ├── Hero.tsx                ← MOVED HERE
│   │   ├── Navigation.tsx          ← MOVED HERE
│   │   ├── Projects.tsx            ← MOVED HERE
│   │   ├── Skills.tsx              ← MOVED HERE
│   │   ├── figma/
│   │   │   └── ImageWithFallback.tsx  ← MOVED HERE
│   │   └── ui/
│   │       ├── accordion.tsx       ← MOVED HERE
│   │       ├── (all other ui files)
│   │       └── utils.ts
│   └── styles/
│       └── globals.css             ← MOVED HERE
├── index.html                      ✓
├── package.json                    ✓
├── vite.config.ts                  ✓
├── tsconfig.json                   ✓
├── postcss.config.js               ✓
├── .gitignore                      ✓
└── README.md                       ✓
```

---

## 🚀 After Files Are Organized

### Step 1: Install Dependencies

```bash
npm install
```

Wait 2-5 minutes...

### Step 2: Start Development Server

```bash
npm run dev
```

### Step 3: Open in Browser

Go to: **http://localhost:5173**

---

## 🐛 Troubleshooting

### Error: "Cannot find module './components/Hero'"

**Cause:** Files are still in wrong location  
**Solution:** Make sure ALL components are in `/src/components/`, not `/components/`

### Error: "Cannot find module './styles/globals.css'"

**Cause:** Styles file is in wrong location  
**Solution:** Move `globals.css` to `/src/styles/`

### Error: Module not found

**Solution:**
1. Delete `node_modules` folder
2. Delete `package-lock.json`
3. Run `npm install` again
4. Run `npm run dev`

---

## 📸 Photo Already Updated!

✅ The girl/woman photo has been updated to a professional developer portrait.

The image is now:
```
https://images.unsplash.com/photo-1712174766230-cb7304feaafe
```

This is a professional woman developer portrait that will show in your Hero section!

---

## ⚡ Quick Checklist

After reorganizing files, verify:

- [ ] `/src/components/` folder exists with 8 component files
- [ ] `/src/components/ui/` folder has all UI components
- [ ] `/src/components/figma/` has ImageWithFallback.tsx
- [ ] `/src/styles/` has globals.css
- [ ] `/src/main.tsx` exists
- [ ] `/src/App.tsx` exists
- [ ] Old `/components/` folder is DELETED
- [ ] Old `/styles/` folder is DELETED
- [ ] Root `App.tsx` is DELETED (only keep the one in /src)
- [ ] Run `npm install` successfully
- [ ] Run `npm run dev` successfully
- [ ] Portfolio opens in browser at localhost:5173

---

## 💡 Pro Tip

After organizing, if you see any import errors:
1. Open the file with the error
2. Check the import paths
3. Make sure they use relative paths like:
   - `./components/Hero` (from App.tsx)
   - `./ui/button` (from component files)
   - `./figma/ImageWithFallback` (from Hero.tsx)

---

**Once organized, your portfolio will work perfectly! 🎉**
