# 📥 How to Download & Setup - Complete Guide

## 🎯 For Beginners - Step by Step

### Part 1: Download Node.js

1. **Open your web browser**
2. **Go to**: https://nodejs.org/
3. **Download** the **LTS version** (Long Term Support) - the green button
4. **Run the installer** and click "Next" on everything
5. **Restart your computer** after installation

### Part 2: Download VS Code

1. **Go to**: https://code.visualstudio.com/
2. **Download** VS Code for your operating system
3. **Install** it with default settings
4. **Open** VS Code

### Part 3: Get the Portfolio Files

**Option A: If you have a ZIP file**
1. **Extract/Unzip** the portfolio folder to your Desktop
2. Remember the folder location (e.g., `C:\Users\YourName\Desktop\farheen-portfolio`)

**Option B: If you have access to Figma Make or the code**
1. Create a new folder on your Desktop called `farheen-portfolio`
2. Copy all the files into this folder

### Part 4: Open in VS Code

1. **Open VS Code**
2. Click **File** → **Open Folder**
3. Navigate to your portfolio folder
4. Click **Select Folder**

### Part 5: Organize Files (IMPORTANT!)

Your files need to be in the correct structure. Follow this:

#### Create the /src folder structure:

1. In VS Code, right-click in the file explorer (left side)
2. Click **New Folder** → name it `src`
3. Inside `src`, create:
   - `components` folder
   - `styles` folder

4. Inside `src/components`, create:
   - `ui` folder
   - `figma` folder

#### Move files to correct locations:

**Drag and drop in VS Code:**

1. Move these to `/src/components/`:
   - Hero.tsx
   - About.tsx
   - Skills.tsx
   - Experience.tsx
   - Projects.tsx
   - Contact.tsx
   - Navigation.tsx
   - Footer.tsx

2. Move all UI files to `/src/components/ui/`:
   - All the .tsx files from components/ui/

3. Move to `/src/components/figma/`:
   - ImageWithFallback.tsx

4. Move to `/src/styles/`:
   - globals.css

5. Make sure these are in the **ROOT** folder (not in src):
   - package.json
   - vite.config.ts
   - tsconfig.json
   - index.html
   - postcss.config.js
   - .gitignore
   - README.md files

### Part 6: Install Dependencies

1. **Open Terminal** in VS Code:
   - Click **Terminal** → **New Terminal**
   - Or press `` Ctrl + ` `` (backtick key)

2. **Type this command** and press Enter:
   ```bash
   npm install
   ```

3. **Wait** 2-5 minutes while it downloads everything
   - You'll see a progress bar
   - Don't close the terminal!

### Part 7: Run the Portfolio

1. **In the same terminal**, type:
   ```bash
   npm run dev
   ```

2. **Wait** a few seconds

3. You'll see something like:
   ```
   VITE v6.0.3  ready in 500 ms

   ➜  Local:   http://localhost:5173/
   ➜  press h + enter to show help
   ```

4. **Hold Ctrl** and **click** on the `http://localhost:5173/` link
   - Or manually open your browser and type: `http://localhost:5173`

5. **🎉 Done!** Your portfolio is running!

## 📝 What You Should See

When you open `http://localhost:5173`, you should see:

1. **Hero Section** - Your name "Farheen" with purple gradient
2. **Smooth animations** - Elements floating and fading in
3. **Navigation bar** at the top
4. **About section** with your bio
5. **Skills section** with categorized skills
6. **Experience timeline**
6. **Projects portfolio**
7. **Contact form**
8. **Footer**

## 🎨 Customize Your Portfolio

### Change Your Name

1. Open `/src/components/Hero.tsx`
2. Find this line (around line 67):
   ```typescript
   <h1>Hi, I'm <span>Farheen</span></h1>
   ```
3. Change "Farheen" to your name
4. Save the file (Ctrl+S)
5. The page will automatically refresh!

### Change Your Email

1. Open `/src/components/Hero.tsx`
2. Find: `farheendeshmukh38@gmail.com`
3. Replace with your email
4. Save (Ctrl+S)

### Change Your Phone

1. Open `/src/components/Hero.tsx`
2. Find: `8262029163`
3. Replace with your number
4. Save (Ctrl+S)

### Add Your Photo

1. Put your photo in the `/public` folder
2. Open `/src/components/Hero.tsx`
3. Find the `ImageWithFallback` component
4. Change the `src` to: `/your-photo-name.jpg`
5. Save (Ctrl+S)

### Add Your CV/Resume

1. Put your CV PDF in `/public` folder (e.g., `my-cv.pdf`)
2. Open `/src/components/Hero.tsx`
3. Find the "Download CV" button code
4. Replace the `onClick` function with:
   ```typescript
   onClick={() => {
     const link = document.createElement("a");
     link.href = "/my-cv.pdf";
     link.download = "Farheen_Deshmukh_CV.pdf";
     link.click();
   }}
   ```
5. Save (Ctrl+S)

## 🛑 Troubleshooting

### Error: "npm is not recognized"

**Solution:**
- Node.js is not installed correctly
- Reinstall Node.js from https://nodejs.org/
- Restart your computer
- Try again

### Error: "Cannot find module"

**Solution:**
- Delete the `node_modules` folder
- Delete the `package-lock.json` file
- Run `npm install` again

### Error: Port already in use

**Solution:**
- Close any other terminal windows
- Or change the port: `npm run dev -- --port 3000`

### Blank White Screen

**Solution:**
- Check terminal for errors
- Make sure all files are in `/src` folder
- Run `npm install` again
- Restart the dev server: Press `Ctrl+C` then `npm run dev`

### Styles Not Loading

**Solution:**
- Check that `globals.css` is in `/src/styles/`
- Check that `main.tsx` has: `import './styles/globals.css'`
- Clear browser cache (Ctrl+Shift+Delete)
- Refresh page (Ctrl+F5)

## 📱 View on Phone

1. Make sure your phone and computer are on the same Wi-Fi
2. In the terminal, you'll see:
   ```
   ➜  Network: http://192.168.1.5:5173/
   ```
3. Open this URL on your phone's browser
4. Your portfolio will load on your phone!

## 🌐 Deploy Online (Make it Live!)

### Deploy to Netlify (FREE)

1. **Build your project:**
   ```bash
   npm run build
   ```

2. **Go to**: https://app.netlify.com/
3. **Sign up** for free
4. **Drag and drop** the `dist` folder to Netlify
5. **Done!** You get a free URL like: `your-portfolio.netlify.app`

### Deploy to Vercel (FREE)

1. **Go to**: https://vercel.com/
2. **Sign up** with GitHub
3. **Import** your project
4. **Deploy**
5. **Done!** You get a free URL like: `your-portfolio.vercel.app`

## 💡 Tips

- **Auto-save**: Enable in VS Code → File → Auto Save
- **Format code**: Press `Shift+Alt+F`
- **Zoom in/out**: Hold `Ctrl` and scroll mouse wheel
- **Find text**: Press `Ctrl+F`
- **Replace text**: Press `Ctrl+H`

## ✅ Success Checklist

After setup, you should have:

- [ ] Node.js installed
- [ ] VS Code installed
- [ ] Portfolio folder opened in VS Code
- [ ] Files organized in `/src` structure
- [ ] `npm install` completed successfully
- [ ] `npm run dev` running without errors
- [ ] Portfolio visible at http://localhost:5173
- [ ] All sections loading correctly
- [ ] Animations working smoothly

## 📧 Still Need Help?

If you're stuck:

1. **Read error messages** carefully in the terminal
2. **Google the error** - copy and paste it
3. **Check all files** are in correct folders
4. **Try `npm install`** again
5. **Restart VS Code** and try again

---

**You've got this! 🚀 Your portfolio will look amazing!**

Email: farheendeshmukh38@gmail.com if you need assistance.
