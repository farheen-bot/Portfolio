# 📁 Folder Structure Setup Guide

## ✅ How to Organize Your Files

Since you're working in VS Code, you need to move files to the `/src` folder. Here's the complete structure:

## 🎯 Final Folder Structure

```
farheen-portfolio/
│
├── public/                          # Static files (images, CV, etc.)
│   └── (your CV file here)
│
├── src/                             # Main source code folder
│   ├── main.tsx                     # App entry point ✓
│   ├── App.tsx                      # Main app component ✓
│   │
│   ├── components/                  # All components here
│   │   ├── Hero.tsx                 # Move from /components/
│   │   ├── About.tsx                # Move from /components/
│   │   ├── Skills.tsx               # Move from /components/
│   │   ├── Experience.tsx           # Move from /components/
│   │   ├── Projects.tsx             # Move from /components/
│   │   ├── Contact.tsx              # Move from /components/
│   │   ├── Navigation.tsx           # Move from /components/
│   │   ├── Footer.tsx               # Move from /components/
│   │   │
│   │   ├── figma/                   # Figma components
│   │   │   └── ImageWithFallback.tsx   # Move from /components/figma/
│   │   │
│   │   └── ui/                      # UI components folder
│   │       ├── accordion.tsx         # Move all from /components/ui/
│   │       ├── alert-dialog.tsx
│   │       ├── alert.tsx
│   │       ├── aspect-ratio.tsx
│   │       ├── avatar.tsx
│   │       ├── badge.tsx
│   │       ├── breadcrumb.tsx
│   │       ├── button.tsx
│   │       ├── calendar.tsx
│   │       ├── card.tsx
│   │       ├── carousel.tsx
│   │       ├── chart.tsx
│   │       ├── checkbox.tsx
│   │       ├── collapsible.tsx
│   │       ├── command.tsx
│   │       ├── context-menu.tsx
│   │       ├── dialog.tsx
│   │       ├── drawer.tsx
│   │       ├── dropdown-menu.tsx
│   │       ├── form.tsx
│   │       ├── hover-card.tsx
│   │       ├── input-otp.tsx
│   │       ├── input.tsx
│   │       ├── label.tsx
│   │       ├── menubar.tsx
│   │       ├── navigation-menu.tsx
│   │       ├── pagination.tsx
│   │       ├── popover.tsx
│   │       ├── progress.tsx
│   │       ├── radio-group.tsx
│   │       ├── resizable.tsx
│   │       ├── scroll-area.tsx
│   │       ├── select.tsx
│   │       ├── separator.tsx
│   │       ├── sheet.tsx
│   │       ├── sidebar.tsx
│   │       ├── skeleton.tsx
│   │       ├── slider.tsx
│   │       ├── sonner.tsx
│   │       ├── switch.tsx
│   │       ├── table.tsx
│   │       ├── tabs.tsx
│   │       ├── textarea.tsx
│   │       ├── toggle-group.tsx
│   │       ├── toggle.tsx
│   │       ├── tooltip.tsx
│   │       ├── use-mobile.ts
│   │       └── utils.ts
│   │
│   └── styles/                      # Styles folder
│       └── globals.css              # Move from /styles/
│
├── index.html                       # HTML entry ✓
├── package.json                     # Dependencies ✓
├── vite.config.ts                  # Vite config ✓
├── tsconfig.json                   # TypeScript config ✓
├── postcss.config.js               # PostCSS config ✓
├── .gitignore                      # Git ignore ✓
├── README.md                       # Documentation ✓
├── SETUP_INSTRUCTIONS.md           # Setup guide ✓
└── QUICK_START_GUIDE.md            # Quick guide ✓
```

## 🔄 Step-by-Step File Moving Process

### Option 1: Manual Moving in VS Code

1. **Create the src folder** (if not exists)
   - Right-click in VS Code Explorer
   - Select "New Folder"
   - Name it `src`

2. **Create subfolders inside src**
   - Create `src/components`
   - Create `src/components/ui`
   - Create `src/components/figma`
   - Create `src/styles`

3. **Move component files**
   - Drag `/components/Hero.tsx` → `/src/components/Hero.tsx`
   - Drag `/components/About.tsx` → `/src/components/About.tsx`
   - Drag `/components/Skills.tsx` → `/src/components/Skills.tsx`
   - Drag `/components/Experience.tsx` → `/src/components/Experience.tsx`
   - Drag `/components/Projects.tsx` → `/src/components/Projects.tsx`
   - Drag `/components/Contact.tsx` → `/src/components/Contact.tsx`
   - Drag `/components/Navigation.tsx` → `/src/components/Navigation.tsx`
   - Drag `/components/Footer.tsx` → `/src/components/Footer.tsx`

4. **Move UI components**
   - Drag all files from `/components/ui/` → `/src/components/ui/`

5. **Move figma components**
   - Drag `/components/figma/ImageWithFallback.tsx` → `/src/components/figma/ImageWithFallback.tsx`

6. **Move styles**
   - Drag `/styles/globals.css` → `/src/styles/globals.css`

7. **Delete old empty folders**
   - Delete `/components` folder
   - Delete `/styles` folder

### Option 2: Using Terminal Commands

Open terminal in VS Code and run:

```bash
# Create src structure
mkdir -p src/components/ui
mkdir -p src/components/figma
mkdir -p src/styles

# Move component files
mv components/*.tsx src/components/
mv components/ui/* src/components/ui/
mv components/figma/* src/components/figma/
mv styles/globals.css src/styles/

# Remove old folders
rm -rf components
rm -rf styles
```

**For Windows Command Prompt:**
```bash
# Create src structure
mkdir src\components\ui
mkdir src\components\figma
mkdir src\styles

# Move files manually or use File Explorer
```

## ✏️ Update Import Paths

After moving files, you need to update import paths in some files:

### 1. Update `/src/components/Hero.tsx`

Change:
```typescript
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
```

To:
```typescript
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
```
(Actually no change needed - relative paths stay the same!)

### 2. All component files already use relative imports, so they should work!

## 🎯 Verification Checklist

After moving files, verify:

- [ ] All files are in `/src` folder
- [ ] `/src/main.tsx` exists
- [ ] `/src/App.tsx` exists
- [ ] `/src/components/` has all component files
- [ ] `/src/components/ui/` has all UI components
- [ ] `/src/components/figma/` has ImageWithFallback.tsx
- [ ] `/src/styles/globals.css` exists
- [ ] `/index.html` is in root
- [ ] `/package.json` is in root
- [ ] No errors when running `npm run dev`

## ⚠️ Common Issues After Moving

**Issue: Module not found errors**
- Make sure all imports use correct relative paths
- Check that file extensions are `.tsx` not `.ts` for React components

**Issue: Styles not loading**
- Verify `/src/styles/globals.css` exists
- Check that `main.tsx` imports it: `import './styles/globals.css'`

**Issue: Components not rendering**
- Check that all component exports are correct
- Verify import paths in `App.tsx`

## 🚀 After Setup Complete

Run these commands:

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

Your portfolio should now be running at `http://localhost:5173`!

---

**Need help? Check the SETUP_INSTRUCTIONS.md or QUICK_START_GUIDE.md files!**
