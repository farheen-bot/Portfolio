import { motion } from "motion/react";
import { Download, Github, Linkedin, Mail, Phone } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
  };

  const floatingVariants = {
    animate: {
      y: [0, -20, 0],
      transition: {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut",
      },
    },
  };

  return (
    <section className="min-h-screen relative overflow-hidden bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-20 left-20 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          className="flex flex-col lg:flex-row items-center justify-between gap-12"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Text Content */}
          <div className="flex-1 text-white space-y-6">
            <motion.div variants={itemVariants}>
              <motion.span
                className="inline-block px-4 py-2 bg-purple-500/20 backdrop-blur-sm rounded-full border border-purple-500/30 mb-4"
                whileHover={{ scale: 1.05 }}
              >
                Cloud Architect
              </motion.span>
            </motion.div>

            <motion.h1 variants={itemVariants} className="text-6xl lg:text-8xl">
              Hi, I'm{" "}
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Farheen
              </span>
            </motion.h1>

            <motion.h2
              variants={itemVariants}
              className="text-3xl lg:text-4xl text-gray-300"
            >
              Farheen Deshmukh
            </motion.h2>

            <motion.p
              variants={itemVariants}
              className="text-xl text-gray-400 max-w-2xl"
            >
              I'm passionate about building intelligent and scalable systems
              using modern cloud technologies, automation tools, and AI
              integration. I design and develop smart applications that combine
              data, intelligence, and user-centric interfaces — helping
              organizations improve efficiency and innovation.
            </motion.p>

            <motion.div
              variants={itemVariants}
              className="flex flex-wrap gap-4 pt-4"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 group"
                onClick={() => {
                  // Open CV in a new window
                  const cvWindow = window.open('', '_blank');
                  if (cvWindow) {
                    cvWindow.document.write(`
                      <!DOCTYPE html>
                      <html>
                        <head>
                          <title>Farheen Deshmukh - CV</title>
                          <style>
                            * { margin: 0; padding: 0; box-sizing: border-box; }
                            body { 
                              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                              line-height: 1.6;
                              color: #1f2937;
                              background: white;
                              padding: 2rem;
                            }
                            .container { max-width: 210mm; margin: 0 auto; }
                            h1 { font-size: 2.5rem; color: #1f2937; margin-bottom: 0.5rem; font-weight: 700; }
                            h2 { 
                              font-size: 1.5rem; 
                              color: #7c3aed; 
                              margin: 1.5rem 0 1rem; 
                              padding-bottom: 0.5rem; 
                              border-bottom: 2px solid #d1d5db;
                              font-weight: 600;
                            }
                            h3 { font-size: 1.1rem; color: #1f2937; margin: 0.75rem 0 0.25rem; font-weight: 600; }
                            p { margin: 0.5rem 0; font-size: 0.95rem; }
                            .header { 
                              border-bottom: 4px solid #7c3aed; 
                              padding-bottom: 1.5rem; 
                              margin-bottom: 1.5rem; 
                            }
                            .subtitle { font-size: 1.2rem; color: #4b5563; margin-bottom: 1rem; font-weight: 500; }
                            .contact-grid { 
                              display: grid; 
                              grid-template-columns: 1fr 1fr; 
                              gap: 0.5rem; 
                              font-size: 0.9rem; 
                              color: #4b5563; 
                            }
                            .section { margin-bottom: 1.5rem; }
                            .project { margin-bottom: 1rem; }
                            .skills-grid { 
                              display: grid; 
                              grid-template-columns: repeat(3, 1fr); 
                              gap: 0.5rem; 
                              font-size: 0.9rem; 
                            }
                            ul { 
                              list-style: disc; 
                              margin-left: 1.5rem; 
                              font-size: 0.95rem; 
                            }
                            li { margin: 0.25rem 0; }
                            .summary { 
                              text-align: justify; 
                              font-size: 0.95rem; 
                              color: #4b5563; 
                              line-height: 1.7; 
                            }
                            .edu-header { 
                              display: flex; 
                              justify-content: space-between; 
                              align-items: flex-start; 
                            }
                            .date { font-size: 0.9rem; color: #6b7280; }
                            @media print {
                              body { padding: 0; }
                              @page { margin: 1cm; }
                            }
                          </style>
                        </head>
                        <body>
                          <div class="container">
                            <div class="header">
                              <h1>Farheen Deshmukh</h1>
                              <p class="subtitle">Cloud Architect & AI Automation Developer</p>
                              <div class="contact-grid">
                                <div>📍 Jalgaon, Maharashtra, India</div>
                                <div>📧 farheendeshmukh38@gmail.com</div>
                                <div>📱 8262029163</div>
                                <div>💼 Cloud Architecture</div>
                              </div>
                            </div>

                            <div class="section">
                              <h2>Professional Summary</h2>
                              <p class="summary">
                                Motivated and innovative B.Tech candidate in Data Science with hands-on experience in cloud architecture, 
                                AI automation, and full stack development. Skilled in building data-driven solutions and cloud-native workflows 
                                using modern DevOps practices. Proven ability in leading AI-powered automation projects, optimizing cloud resources, 
                                and delivering scalable digital solutions.
                              </p>
                            </div>

                            <div class="section">
                              <h2>Education</h2>
                              <div class="edu-header">
                                <h3>B.Tech in Data Science</h3>
                                <span class="date">Expected: August 2026</span>
                              </div>
                              <p>GH Raisoni College of Engineering and Management Jalgaon</p>
                              <p>GPA: 7.85 | Jalgaon, Maharashtra, India</p>
                            </div>

                            <div class="section">
                              <h2>Certifications</h2>
                              <ul>
                                <li>Oracle Cloud Infrastructure</li>
                                <li>Google Cloud Professional Cloud Architect</li>
                                <li>Cloud Computing (IBM)</li>
                              </ul>
                            </div>

                            <div class="section">
                              <h2>Projects</h2>
                              
                              <div class="project">
                                <h3>AI Cloud Workflow Automation System</h3>
                                <p>Designed and deployed an end-to-end AI-powered workflow system on AWS for automated task 
                                orchestration and resource management.</p>
                              </div>

                              <div class="project">
                                <h3>Cloud-Based AI Chat Assistant (Multi-Agent System)</h3>
                                <p>Built a scalable chat assistant using multiple AI agents, enabling intelligent customer 
                                interactions and cloud integration.</p>
                              </div>

                              <div class="project">
                                <h3>Automated Data Pipeline for Predictive Analytics</h3>
                                <p>Developed a robust data pipeline using Python and CI/CD tools to enable real-time predictive analytics.</p>
                              </div>

                              <div class="project">
                                <h3>AI-Powered Cost Optimization Tool for AWS</h3>
                                <p>Created an AI algorithm to optimize resource allocation and reduce cloud infrastructure costs.</p>
                              </div>

                              <div class="project">
                                <h3>Intelligent Cloud Deployment Manager</h3>
                                <p>Engineered a deployment manager leveraging Kubernetes and Terraform for seamless application 
                                deployments in the cloud.</p>
                              </div>
                            </div>

                            <div class="section">
                              <h2>Technical Skills</h2>
                              <div class="skills-grid">
                                <div>• AI Automation</div>
                                <div>• AWS</div>
                                <div>• CI/CD</div>
                                <div>• Cloud Architecture</div>
                                <div>• Data Analytics</div>
                                <div>• Data-Driven Solutions</div>
                                <div>• DevOps</div>
                                <div>• Docker</div>
                                <div>• Full Stack Development</div>
                                <div>• GitHub</div>
                                <div>• Grafana</div>
                                <div>• JavaScript</div>
                                <div>• Jenkins</div>
                                <div>• Kubernetes</div>
                                <div>• Python</div>
                                <div>• Terraform</div>
                              </div>
                            </div>
                          </div>
                        </body>
                      </html>
                    `);
                    cvWindow.document.close();
                  }
                }}
              >
                <Download className="mr-2 group-hover:animate-bounce" />
                Download CV
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="border-purple-500/30 hover:bg-purple-500/10 text-white"
                onClick={() =>
                  document
                    .getElementById("contact")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
              >
                Get in Touch
              </Button>
            </motion.div>

            {/* Social Links */}
            <motion.div
              variants={itemVariants}
              className="flex gap-4 pt-4"
            >
              <motion.a
                href="https://github.com/farheendeshmukh"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-colors"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Github className="w-6 h-6" />
              </motion.a>
              <motion.a
                href="https://www.linkedin.com/in/farheen-deshmukh-65bb6b389?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-colors"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Linkedin className="w-6 h-6" />
              </motion.a>
              <motion.a
                href="mailto:farheendeshmukh38@gmail.com"
                className="p-3 bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-colors"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail className="w-6 h-6" />
              </motion.a>
              <motion.a
                href="tel:8262029163"
                className="p-3 bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-colors"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Phone className="w-6 h-6" />
              </motion.a>
            </motion.div>
          </div>

          {/* Profile Image */}
          <motion.div
            className="flex-1 flex justify-center lg:justify-end"
            variants={floatingVariants}
            animate="animate"
          >
            <motion.div
              className="relative"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl blur-2xl opacity-50"></div>
              <div className="relative w-80 h-80 lg:w-96 lg:h-96 rounded-3xl overflow-hidden border-4 border-purple-500/30 shadow-2xl transform perspective-1000 rotate-y-6">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1712174766230-cb7304feaafe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b21hbiUyMGRldmVsb3BlciUyMHBvcnRyYWl0fGVufDF8fHx8MTc2MTA0MDk4M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Farheen Deshmukh - Professional Developer"
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
