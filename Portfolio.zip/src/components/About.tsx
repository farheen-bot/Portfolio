import { motion } from "motion/react";
import { Code2, Cloud, Brain, Sparkles } from "lucide-react";

export function About() {
  const highlights = [
    {
      icon: Cloud,
      title: "Cloud Architecture",
      description: "Designing scalable and resilient cloud infrastructures",
    },
    {
      icon: Brain,
      title: "AI Integration",
      description: "Building intelligent systems with machine learning",
    },
    {
      icon: Code2,
      title: "Automation",
      description: "Streamlining workflows with smart automation",
    },
    {
      icon: Sparkles,
      title: "Innovation",
      description: "Creating cutting-edge solutions for modern challenges",
    },
  ];

  return (
    <section id="about" className="py-20 bg-slate-900 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-4 text-white">
            About <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Me</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm rounded-3xl p-8 lg:p-12 border border-purple-500/20 shadow-2xl mb-12"
          >
            <p className="text-gray-300 text-xl leading-relaxed mb-6">
              Hi, I'm <span className="text-purple-400">Farheen Deshmukh</span> — a passionate{" "}
              <span className="text-pink-400">Cloud Architect</span> with a mission to transform
              how organizations leverage technology.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed mb-6">
              With expertise spanning across multiple cloud platforms, automation frameworks, and AI technologies,
              I specialize in designing and developing intelligent systems that are not only scalable and secure
              but also push the boundaries of what's possible with modern technology.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed">
              My approach combines deep technical knowledge with a user-centric design philosophy. I believe
              that the best solutions are those that seamlessly integrate data, intelligence, and intuitive
              interfaces — empowering organizations to work smarter, faster, and more efficiently.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -10, scale: 1.05 }}
                  className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 group"
                >
                  <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-white text-xl mb-2">{item.title}</h3>
                  <p className="text-gray-400">{item.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
