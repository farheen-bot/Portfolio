import { motion } from "motion/react";
import { Briefcase, Award, TrendingUp, Users } from "lucide-react";
import { Card } from "./ui/card";

export function Experience() {
  const experiences = [
    {
      role: "Cloud Architect",
      company: "Tech Innovations Inc.",
      period: "Present",
      description:
        "Leading cloud infrastructure design and implementation for enterprise clients, focusing on AWS and Azure multi-cloud solutions.",
      achievements: [
        "Architected and deployed scalable cloud infrastructure serving 10M+ users",
        "Reduced infrastructure costs by 40% through optimization and automation",
        "Led migration of legacy systems to cloud-native microservices architecture",
        "Implemented CI/CD pipelines reducing deployment time by 70%",
      ],
      technologies: [
        "AWS",
        "Azure",
        "Kubernetes",
        "Terraform",
        "Docker",
        "Python",
      ],
    },
    {
      role: "Cloud Solutions Architect",
      company: "AI Solutions Lab",
      period: "Previous",
      description:
        "Developed intelligent automation solutions using machine learning and AI technologies to streamline business processes.",
      achievements: [
        "Built AI-powered chatbots handling 50K+ customer queries daily",
        "Developed ML models achieving 95% accuracy for predictive analytics",
        "Automated business processes saving 500+ hours/month",
        "Integrated OpenAI and custom ML models into production systems",
      ],
      technologies: [
        "Python",
        "TensorFlow",
        "LangChain",
        "OpenAI API",
        "FastAPI",
        "MongoDB",
      ],
    },
    {
      role: "DevOps Engineer",
      company: "CloudScale Systems",
      period: "Previous",
      description:
        "Managed cloud infrastructure and implemented DevOps practices for continuous integration and deployment.",
      achievements: [
        "Implemented infrastructure as code using Terraform and CloudFormation",
        "Set up monitoring and alerting systems with Prometheus and Grafana",
        "Automated deployment processes for 50+ microservices",
        "Improved system reliability to 99.99% uptime",
      ],
      technologies: [
        "AWS",
        "Jenkins",
        "Docker",
        "Kubernetes",
        "Ansible",
        "Prometheus",
      ],
    },
  ];

  const stats = [
    {
      icon: Briefcase,
      value: "Expert",
      label: "Cloud Architecture",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Award,
      value: "50+",
      label: "Projects Completed",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Users,
      value: "20+",
      label: "Happy Clients",
      color: "from-orange-500 to-red-500",
    },
    {
      icon: TrendingUp,
      value: "99.9%",
      label: "Success Rate",
      color: "from-green-500 to-emerald-500",
    },
  ];

  return (
    <section id="experience" className="py-20 bg-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-4 text-white">
            Work <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Experience</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto rounded-full"></div>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
              >
                <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 p-6 text-center group">
                  <div className={`w-14 h-14 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <div className={`text-4xl bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                    {stat.value}
                  </div>
                  <div className="text-gray-400">{stat.label}</div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="relative pl-8 pb-12 last:pb-0"
            >
              {/* Timeline line */}
              {index !== experiences.length - 1 && (
                <div className="absolute left-[11px] top-8 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 to-pink-500"></div>
              )}

              {/* Timeline dot */}
              <div className="absolute left-0 top-2 w-6 h-6 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full border-4 border-slate-900 shadow-lg shadow-purple-500/50"></div>

              <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 p-6 lg:p-8 group">
                <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                  <div>
                    <h3 className="text-2xl text-white mb-2 group-hover:text-purple-400 transition-colors">
                      {exp.role}
                    </h3>
                    <p className="text-purple-400 text-lg">{exp.company}</p>
                  </div>
                  <span className="px-4 py-2 bg-purple-500/20 rounded-full text-purple-300 border border-purple-500/30">
                    {exp.period}
                  </span>
                </div>

                <p className="text-gray-400 mb-6 leading-relaxed">
                  {exp.description}
                </p>

                <div className="mb-6">
                  <h4 className="text-white mb-3">Key Achievements:</h4>
                  <ul className="space-y-2">
                    {exp.achievements.map((achievement, i) => (
                      <motion.li
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: i * 0.1 }}
                        className="text-gray-400 flex items-start gap-2"
                      >
                        <span className="text-purple-400 mt-1.5">▹</span>
                        <span>{achievement}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>

                <div className="flex flex-wrap gap-2">
                  {exp.technologies.map((tech, i) => (
                    <motion.span
                      key={i}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.3, delay: i * 0.05 }}
                      whileHover={{ scale: 1.1 }}
                      className="px-3 py-1 bg-slate-800/50 text-purple-300 rounded-full text-sm border border-purple-500/30 hover:border-purple-500/60 transition-all"
                    >
                      {tech}
                    </motion.span>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
