import { motion } from "motion/react";
import { useState } from "react";
import {
  Cloud,
  Server,
  Code,
  Database,
  Container,
  Lock,
  Workflow,
  Brain,
  Cpu,
  Network,
  Shield,
  Zap,
} from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

export function Skills() {
  const [activeCategory, setActiveCategory] = useState("all");

  const skillCategories = [
    {
      id: "cloud",
      name: "Cloud Platforms",
      icon: Cloud,
      color: "from-blue-500 to-cyan-500",
      skills: [
        {
          name: "Amazon Web Services (AWS)",
          level: "Expert",
          description: "EC2, S3, Lambda, RDS, DynamoDB, CloudFormation, ECS, EKS, API Gateway, CloudWatch",
          icon: Cloud,
        },
        {
          name: "Microsoft Azure",
          level: "Advanced",
          description: "Virtual Machines, Azure Functions, Cosmos DB, Azure DevOps, AKS, Logic Apps, App Services",
          icon: Cloud,
        },
        {
          name: "Google Cloud Platform",
          level: "Advanced",
          description: "Compute Engine, Cloud Functions, BigQuery, Cloud Storage, GKE, Cloud Run, Pub/Sub",
          icon: Cloud,
        },
        {
          name: "Multi-Cloud Architecture",
          level: "Expert",
          description: "Cross-cloud migration, hybrid cloud solutions, cloud-agnostic designs, cost optimization",
          icon: Network,
        },
      ],
    },
    {
      id: "automation",
      name: "AI & Automation",
      icon: Brain,
      color: "from-purple-500 to-pink-500",
      skills: [
        {
          name: "Machine Learning & AI",
          level: "Expert",
          description: "TensorFlow, PyTorch, Scikit-learn, NLP, Computer Vision, Model Deployment, MLOps",
          icon: Brain,
        },
        {
          name: "AI Automation Tools",
          level: "Expert",
          description: "LangChain, OpenAI API, Anthropic Claude, Hugging Face, AutoML, AI Orchestration",
          icon: Zap,
        },
        {
          name: "RPA & Process Automation",
          level: "Advanced",
          description: "UiPath, Power Automate, Zapier, n8n, Workflow Automation, Business Process Optimization",
          icon: Workflow,
        },
        {
          name: "DevOps & CI/CD",
          level: "Expert",
          description: "Jenkins, GitLab CI, GitHub Actions, Azure DevOps, ArgoCD, Terraform, Ansible",
          icon: Server,
        },
      ],
    },
    {
      id: "infrastructure",
      name: "Infrastructure & DevOps",
      icon: Server,
      color: "from-orange-500 to-red-500",
      skills: [
        {
          name: "Containerization",
          level: "Expert",
          description: "Docker, Kubernetes, Helm, Docker Compose, Container Orchestration, Microservices",
          icon: Container,
        },
        {
          name: "Infrastructure as Code",
          level: "Expert",
          description: "Terraform, CloudFormation, Pulumi, ARM Templates, Infrastructure Automation",
          icon: Code,
        },
        {
          name: "Configuration Management",
          level: "Advanced",
          description: "Ansible, Chef, Puppet, Salt, Configuration Automation, System Administration",
          icon: Server,
        },
        {
          name: "Monitoring & Observability",
          level: "Expert",
          description: "Prometheus, Grafana, ELK Stack, CloudWatch, Datadog, New Relic, APM Tools",
          icon: Cpu,
        },
      ],
    },
    {
      id: "development",
      name: "Development & Databases",
      icon: Code,
      color: "from-green-500 to-emerald-500",
      skills: [
        {
          name: "Programming Languages",
          level: "Expert",
          description: "Python, JavaScript/TypeScript, Go, Bash, PowerShell, Java, SQL",
          icon: Code,
        },
        {
          name: "Web Development",
          level: "Advanced",
          description: "React, Node.js, Next.js, FastAPI, Flask, RESTful APIs, GraphQL, WebSockets",
          icon: Code,
        },
        {
          name: "Databases",
          level: "Expert",
          description: "PostgreSQL, MongoDB, Redis, MySQL, DynamoDB, Cosmos DB, Elasticsearch, Neo4j",
          icon: Database,
        },
        {
          name: "Message Queues & Streaming",
          level: "Advanced",
          description: "Kafka, RabbitMQ, AWS SQS/SNS, Azure Service Bus, Event-driven Architecture",
          icon: Network,
        },
      ],
    },
    {
      id: "security",
      name: "Security & Compliance",
      icon: Shield,
      color: "from-red-500 to-pink-500",
      skills: [
        {
          name: "Cloud Security",
          level: "Expert",
          description: "IAM, VPC, Security Groups, NACL, WAF, GuardDuty, Security Hub, Encryption",
          icon: Lock,
        },
        {
          name: "DevSecOps",
          level: "Advanced",
          description: "Security Scanning, SAST/DAST, Container Security, Secret Management, Compliance Automation",
          icon: Shield,
        },
        {
          name: "Identity & Access",
          level: "Advanced",
          description: "OAuth, SAML, JWT, Azure AD, AWS IAM, SSO, MFA, Zero Trust Architecture",
          icon: Lock,
        },
        {
          name: "Compliance",
          level: "Advanced",
          description: "GDPR, HIPAA, SOC 2, ISO 27001, Audit Logging, Policy as Code",
          icon: Shield,
        },
      ],
    },
  ];

  const categories = [
    { id: "all", name: "All Skills", icon: Cpu },
    ...skillCategories.map((cat) => ({
      id: cat.id,
      name: cat.name,
      icon: cat.icon,
    })),
  ];

  const filteredCategories =
    activeCategory === "all"
      ? skillCategories
      : skillCategories.filter((cat) => cat.id === activeCategory);

  return (
    <section id="skills" className="py-20 bg-gradient-to-br from-slate-950 via-purple-950/50 to-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='1' fill-rule='evenodd'/%3E%3C/svg%3E")`,
        }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-4 text-white">
            Technical <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Skills</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto rounded-full mb-6"></div>
          <p className="text-gray-400 text-xl max-w-3xl mx-auto">
            Comprehensive expertise across cloud platforms, AI automation, infrastructure, and modern development technologies
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <motion.button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full flex items-center gap-2 transition-all duration-300 ${
                  activeCategory === category.id
                    ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/50"
                    : "bg-slate-800/50 text-gray-400 hover:bg-slate-800 border border-purple-500/20"
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className="w-5 h-5" />
                {category.name}
              </motion.button>
            );
          })}
        </motion.div>

        {/* Skills Grid */}
        <div className="space-y-12">
          {filteredCategories.map((category, catIndex) => {
            const CategoryIcon = category.icon;
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: catIndex * 0.1 }}
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center`}>
                    <CategoryIcon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-3xl text-white">{category.name}</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {category.skills.map((skill, skillIndex) => {
                    const SkillIcon = skill.icon;
                    return (
                      <motion.div
                        key={skillIndex}
                        initial={{ opacity: 0, scale: 0.9 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: skillIndex * 0.05 }}
                        whileHover={{ y: -5, scale: 1.02 }}
                      >
                        <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 p-6 h-full group">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center gap-3 flex-1">
                              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                                <SkillIcon className="w-5 h-5 text-white" />
                              </div>
                              <div className="flex-1">
                                <h4 className="text-white text-xl mb-1">{skill.name}</h4>
                                <Badge
                                  variant="outline"
                                  className={`bg-gradient-to-r ${category.color} border-0 text-white`}
                                >
                                  {skill.level}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <p className="text-gray-400 leading-relaxed">
                            {skill.description}
                          </p>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
