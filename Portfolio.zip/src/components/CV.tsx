export function CV() {
  return (
    <div className="bg-white text-gray-900 max-w-[210mm] mx-auto p-8 min-h-[297mm]">
      {/* Header */}
      <div className="border-b-4 border-purple-600 pb-6 mb-6">
        <h1 className="text-4xl text-gray-900 mb-2">Farheen Deshmukh</h1>
        <p className="text-lg text-gray-700 mb-4">Cloud Architect & AI Automation Developer</p>
        <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
          <div>📍 Jalgaon, Maharashtra, India</div>
          <div>📧 farheendeshmukh38@gmail.com</div>
          <div>📱 8262029163</div>
          <div>💼 Cloud Architecture</div>
        </div>
      </div>

      {/* Professional Summary */}
      <div className="mb-6">
        <h2 className="text-2xl text-purple-700 mb-3 pb-2 border-b-2 border-gray-300">Professional Summary</h2>
        <p className="text-sm text-gray-700 leading-relaxed">
          Motivated and innovative B.Tech candidate in Data Science with hands-on experience in cloud architecture, 
          AI automation, and full stack development. Skilled in building data-driven solutions and cloud-native workflows 
          using modern DevOps practices. Proven ability in leading AI-powered automation projects, optimizing cloud resources, 
          and delivering scalable digital solutions.
        </p>
      </div>

      {/* Education */}
      <div className="mb-6">
        <h2 className="text-2xl text-purple-700 mb-3 pb-2 border-b-2 border-gray-300">Education</h2>
        <div className="mb-3">
          <div className="flex justify-between items-start mb-1">
            <h3 className="text-lg text-gray-900">B.Tech in Data Science</h3>
            <span className="text-sm text-gray-600">Expected: August 2026</span>
          </div>
          <p className="text-sm text-gray-700">GH Raisoni College of Engineering and Management Jalgaon</p>
          <p className="text-sm text-gray-600">GPA: 7.85</p>
          <p className="text-sm text-gray-600">Jalgaon, Maharashtra, India</p>
        </div>
      </div>

      {/* Certifications */}
      <div className="mb-6">
        <h2 className="text-2xl text-purple-700 mb-3 pb-2 border-b-2 border-gray-300">Certifications</h2>
        <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
          <li>Oracle Cloud Infrastructure</li>
          <li>Google Cloud Professional Cloud Architect</li>
          <li>Cloud Computing (IBM)</li>
        </ul>
      </div>

      {/* Projects */}
      <div className="mb-6">
        <h2 className="text-2xl text-purple-700 mb-3 pb-2 border-b-2 border-gray-300">Projects</h2>
        
        <div className="space-y-4">
          <div>
            <h3 className="text-base text-gray-900 mb-1">AI Cloud Workflow Automation System</h3>
            <p className="text-sm text-gray-700">
              Designed and deployed an end-to-end AI-powered workflow system on AWS for automated task 
              orchestration and resource management.
            </p>
          </div>

          <div>
            <h3 className="text-base text-gray-900 mb-1">Cloud-Based AI Chat Assistant (Multi-Agent System)</h3>
            <p className="text-sm text-gray-700">
              Built a scalable chat assistant using multiple AI agents, enabling intelligent customer 
              interactions and cloud integration.
            </p>
          </div>

          <div>
            <h3 className="text-base text-gray-900 mb-1">Automated Data Pipeline for Predictive Analytics</h3>
            <p className="text-sm text-gray-700">
              Developed a robust data pipeline using Python and CI/CD tools to enable real-time predictive analytics.
            </p>
          </div>

          <div>
            <h3 className="text-base text-gray-900 mb-1">AI-Powered Cost Optimization Tool for AWS</h3>
            <p className="text-sm text-gray-700">
              Created an AI algorithm to optimize resource allocation and reduce cloud infrastructure costs.
            </p>
          </div>

          <div>
            <h3 className="text-base text-gray-900 mb-1">Intelligent Cloud Deployment Manager</h3>
            <p className="text-sm text-gray-700">
              Engineered a deployment manager leveraging Kubernetes and Terraform for seamless application 
              deployments in the cloud.
            </p>
          </div>
        </div>
      </div>

      {/* Skills */}
      <div className="mb-6">
        <h2 className="text-2xl text-purple-700 mb-3 pb-2 border-b-2 border-gray-300">Technical Skills</h2>
        <div className="grid grid-cols-3 gap-2 text-sm text-gray-700">
          <div>• AI Automation</div>
          <div>• AWS</div>
          <div>• CI/CD</div>
          <div>• Cloud Architecture</div>
          <div>• Data Analytics</div>
          <div>• Data-Driven Solutions</div>
          <div>• DevOps</div>
          <div>• Docker</div>
          <div>• Full Stack Development</div>
          <div>• GitHub</div>
          <div>• Grafana</div>
          <div>• JavaScript</div>
          <div>• Jenkins</div>
          <div>• Kubernetes</div>
          <div>• Python</div>
          <div>• Terraform</div>
        </div>
      </div>
    </div>
  );
}
