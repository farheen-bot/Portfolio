import { motion } from "motion/react";
import { Cloud, Brain, Zap, Database, Lock, Workflow } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Projects() {
  const projects = [
    {
      title: "Multi-Cloud Infrastructure Automation",
      description:
        "Developed a comprehensive infrastructure automation platform supporting AWS, Azure, and GCP. Implemented automated deployment pipelines, monitoring, and disaster recovery systems.",
      image: "https://images.unsplash.com/photo-1667984390553-7f439e6ae401?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG91ZCUyMGNvbXB1dGluZyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYxMDEwNzk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Cloud,
      color: "from-blue-500 to-cyan-500",
      technologies: ["AWS", "Azure", "GCP", "Terraform", "Kubernetes", "Python"],
      features: [
        "Multi-cloud resource provisioning and management",
        "Automated failover and disaster recovery",
        "Cost optimization with intelligent resource scaling",
        "Unified monitoring and alerting across clouds",
      ],
      github: "#",
      demo: "#",
    },
    {
      title: "AI-Powered Chatbot Platform",
      description:
        "Built an intelligent chatbot platform using OpenAI GPT-4, LangChain, and custom ML models. Handles customer support, sales inquiries, and automated workflows.",
      image: "https://images.unsplash.com/photo-1744868562210-fffb7fa882d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGF1dG9tYXRpb24lMjBuZXR3b3JrfGVufDF8fHx8MTc2MDk4MTg4M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Brain,
      color: "from-purple-500 to-pink-500",
      technologies: ["Python", "OpenAI API", "LangChain", "FastAPI", "Redis", "PostgreSQL"],
      features: [
        "Natural language understanding with GPT-4",
        "Context-aware conversations with memory",
        "Integration with business systems and databases",
        "Real-time analytics and performance tracking",
      ],
      github: "#",
      demo: "#",
    },
    {
      title: "Serverless Data Processing Pipeline",
      description:
        "Designed and implemented a scalable serverless data processing pipeline using AWS Lambda, Step Functions, and various data services for real-time analytics.",
      image: "https://images.unsplash.com/photo-1549399905-5d1bad747576?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3b3Jrc3BhY2UlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2MDk5OTg5OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Zap,
      color: "from-orange-500 to-red-500",
      technologies: ["AWS Lambda", "Step Functions", "DynamoDB", "S3", "Kinesis", "Python"],
      features: [
        "Processing 1M+ events per day with auto-scaling",
        "Real-time data transformation and enrichment",
        "Event-driven architecture with fault tolerance",
        "Cost-efficient serverless infrastructure",
      ],
      github: "#",
      demo: "#",
    },
    {
      title: "ML Model Deployment Platform",
      description:
        "Created an MLOps platform for automated model training, versioning, deployment, and monitoring. Supports multiple ML frameworks and deployment targets.",
      image: "https://images.unsplash.com/photo-1667984390553-7f439e6ae401?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG91ZCUyMGNvbXB1dGluZyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYxMDEwNzk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Database,
      color: "from-green-500 to-emerald-500",
      technologies: ["TensorFlow", "PyTorch", "Docker", "Kubernetes", "MLflow", "FastAPI"],
      features: [
        "Automated model training and hyperparameter tuning",
        "Model versioning and experiment tracking",
        "A/B testing and canary deployments",
        "Real-time model performance monitoring",
      ],
      github: "#",
      demo: "#",
    },
    {
      title: "Zero Trust Security Framework",
      description:
        "Implemented a comprehensive zero trust security framework with identity-based access control, encryption, and continuous verification for cloud infrastructure.",
      image: "https://images.unsplash.com/photo-1744868562210-fffb7fa882d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGF1dG9tYXRpb24lMjBuZXR3b3JrfGVufDF8fHx8MTc2MDk4MTg4M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Lock,
      color: "from-red-500 to-pink-500",
      technologies: ["AWS IAM", "Azure AD", "OAuth", "Terraform", "Python", "Vault"],
      features: [
        "Identity-based access with MFA and SSO",
        "Network micro-segmentation",
        "Automated threat detection and response",
        "Compliance monitoring and reporting",
      ],
      github: "#",
      demo: "#",
    },
    {
      title: "Business Process Automation Suite",
      description:
        "Developed an intelligent automation suite that streamlines business processes using RPA, AI, and workflow orchestration tools.",
      image: "https://images.unsplash.com/photo-1549399905-5d1bad747576?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3b3Jrc3BhY2UlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2MDk5OTg5OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Workflow,
      color: "from-indigo-500 to-purple-500",
      technologies: ["Python", "n8n", "Power Automate", "APIs", "MongoDB", "Node.js"],
      features: [
        "Automated document processing and data extraction",
        "Integration with 50+ business applications",
        "Custom workflow designer and orchestration",
        "Analytics dashboard for process insights",
      ],
      github: "#",
      demo: "#",
    },
  ];

  return (
    <section id="projects" className="py-20 bg-gradient-to-br from-slate-950 via-purple-950/50 to-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='1' fill-rule='evenodd'/%3E%3C/svg%3E")`,
        }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-4 text-white">
            Featured <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto rounded-full mb-6"></div>
          <p className="text-gray-400 text-xl max-w-3xl mx-auto">
            Innovative cloud architecture and AI automation projects that drive business transformation
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 overflow-hidden group h-full flex flex-col">
                  {/* Project Image */}
                  <div className="relative h-56 overflow-hidden">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent"></div>
                    <div className={`absolute top-4 right-4 w-12 h-12 bg-gradient-to-br ${project.color} rounded-xl flex items-center justify-center shadow-lg`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-2xl text-white mb-3 group-hover:text-purple-400 transition-colors">
                      {project.title}
                    </h3>

                    <p className="text-gray-400 mb-4 leading-relaxed">
                      {project.description}
                    </p>

                    <div className="mb-4">
                      <h4 className="text-white mb-2">Key Features:</h4>
                      <ul className="space-y-1">
                        {project.features.map((feature, i) => (
                          <li key={i} className="text-gray-400 text-sm flex items-start gap-2">
                            <span className="text-purple-400 mt-1">▹</span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-6">
                      {project.technologies.map((tech, i) => (
                        <Badge
                          key={i}
                          variant="outline"
                          className={`bg-gradient-to-r ${project.color} border-0 text-white text-xs`}
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
