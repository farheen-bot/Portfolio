# Farheen Deshmukh Portfolio - Setup Instructions

This is a modern, 3D animated portfolio website built with React, TypeScript, Tailwind CSS, and Framer Motion.

## 📋 Prerequisites

Before you begin, make sure you have the following installed on your computer:

- **Node.js** (version 16 or higher) - [Download here](https://nodejs.org/)
- **VS Code** - [Download here](https://code.visualstudio.com/)
- **Git** (optional but recommended) - [Download here](https://git-scm.com/)

## 🚀 Installation Steps

### Step 1: Open VS Code

1. Launch Visual Studio Code on your computer

### Step 2: Open Terminal in VS Code

1. In VS Code, go to **Terminal** → **New Terminal** (or press `` Ctrl+` ``)
2. This will open a terminal at the bottom of VS Code

### Step 3: Navigate to Your Project Folder

If you have the project files in a folder, navigate to it:

```bash
cd path/to/your/portfolio-folder
```

For example:
```bash
cd C:\Users\YourName\Desktop\farheen-portfolio
```

### Step 4: Install Dependencies

Run this command to install all required packages:

```bash
npm install
```

This will install:
- React
- TypeScript
- Tailwind CSS
- Framer Motion (for 3D animations)
- Lucide React (for icons)
- Recharts (for charts)
- ShadCN UI components
- And all other dependencies

**Note:** This may take 2-5 minutes depending on your internet speed.

### Step 5: Start the Development Server

After installation is complete, run:

```bash
npm run dev
```

### Step 6: Open in Browser

1. After running the command, you'll see a message like:
   ```
   ➜  Local:   http://localhost:5173/
   ```

2. Hold **Ctrl** and **click** on the link, or open your browser and go to:
   ```
   http://localhost:5173/
   ```

3. Your portfolio website is now running! 🎉

## 📁 Project Structure

```
farheen-portfolio/
├── src/
│   ├── App.tsx                 # Main application component
│   ├── components/
│   │   ├── Hero.tsx           # Hero section with your intro
│   │   ├── About.tsx          # About section
│   │   ├── Skills.tsx         # Skills showcase
│   │   ├── Experience.tsx     # Work experience timeline
│   │   ├── Projects.tsx       # Projects portfolio
│   │   ├── Contact.tsx        # Contact form and info
│   │   ├── Navigation.tsx     # Navigation bar
│   │   ├── Footer.tsx         # Footer section
│   │   └── ui/                # UI components (buttons, cards, etc.)
│   └── styles/
│       └── globals.css        # Global styles and Tailwind config
├── package.json               # Dependencies and scripts
├── tsconfig.json             # TypeScript configuration
├── vite.config.ts            # Vite configuration
└── index.html                # HTML entry point
```

## 🎨 Customization Guide

### Change Your Information

#### 1. Update Personal Details

Open `/components/Hero.tsx` and modify:
- Your name
- Your title/role
- Your introduction text
- Contact information (email, phone, GitHub, LinkedIn)

#### 2. Update About Section

Edit `/components/About.tsx` to change your bio and highlights.

#### 3. Modify Skills

Edit `/components/Skills.tsx` to add/remove skills and technologies.

#### 4. Update Experience

Edit `/components/Experience.tsx` to add your actual work experience.

#### 5. Change Projects

Edit `/components/Projects.tsx` to showcase your real projects.

#### 6. Update Contact Info

Edit `/components/Contact.tsx` to update contact details.

### Change Colors

The portfolio uses a purple-pink gradient theme. To change colors:

1. Open `/styles/globals.css`
2. Find the color definitions
3. Replace with your preferred colors

Example color classes used:
- `from-purple-500 to-pink-500` - Main gradient
- `bg-slate-900` - Dark background
- `text-purple-400` - Accent text

### Add Your CV/Resume

To enable CV download:

1. Add your CV file to the `/public` folder (e.g., `Farheen_Deshmukh_CV.pdf`)
2. Open `/components/Hero.tsx`
3. Find the "Download CV" button section
4. Replace the mock download with:

```typescript
onClick={() => {
  const link = document.createElement("a");
  link.href = "/Farheen_Deshmukh_CV.pdf";
  link.download = "Farheen_Deshmukh_CV.pdf";
  link.click();
}}
```

## 🛠️ Common Commands

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Check for errors
npm run lint
```

## 📱 Responsive Design

The portfolio is fully responsive and works on:
- 📱 Mobile devices (phones)
- 📱 Tablets
- 💻 Laptops
- 🖥️ Desktop computers

## 🌐 Deployment

### Deploy to Netlify (Recommended - Free)

1. Build the project:
   ```bash
   npm run build
   ```

2. Sign up at [Netlify](https://www.netlify.com/)

3. Drag and drop the `dist` folder to Netlify

4. Your site is live! 🎉

### Deploy to Vercel (Also Free)

1. Install Vercel CLI:
   ```bash
   npm install -g vercel
   ```

2. Deploy:
   ```bash
   vercel
   ```

3. Follow the prompts

### Deploy to GitHub Pages

1. Install gh-pages:
   ```bash
   npm install --save-dev gh-pages
   ```

2. Add to `package.json`:
   ```json
   "homepage": "https://yourusername.github.io/portfolio",
   "scripts": {
     "predeploy": "npm run build",
     "deploy": "gh-pages -d dist"
   }
   ```

3. Deploy:
   ```bash
   npm run deploy
   ```

## 🐛 Troubleshooting

### Issue: npm install fails

**Solution:**
1. Delete `node_modules` folder and `package-lock.json`
2. Run `npm install` again

### Issue: Port 5173 already in use

**Solution:**
1. Kill the process using that port
2. Or change the port in `vite.config.ts`

### Issue: Styles not loading

**Solution:**
1. Make sure Tailwind CSS is properly installed
2. Check that `globals.css` is imported in your main file

### Issue: Images not showing

**Solution:**
1. Check internet connection (images are from Unsplash)
2. Or replace with local images in the `/public` folder

## 📧 Support

If you encounter any issues:

1. Check the error message in the terminal
2. Search for the error on Google or Stack Overflow
3. Make sure all dependencies are installed correctly

## 🎓 Technologies Used

- **React 18** - UI library
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Animation library for 3D effects
- **Vite** - Fast build tool
- **Lucide React** - Beautiful icons
- **ShadCN UI** - Component library

## 📄 License

This project is created for Farheen Deshmukh's personal portfolio.

---

**Made with ❤️ by Farheen Deshmukh**

For any questions or customization help, feel free to reach out!

📧 Email: farheendeshmukh38@gmail.com
📱 Phone: +91 8262029163
