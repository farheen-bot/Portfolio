# 🌟 Farheen Deshmukh Portfolio

A stunning 3D animated portfolio website showcasing expertise in Cloud Architecture and AI Automation Development.

![Portfolio Preview](https://img.shields.io/badge/React-18.3.1-blue?logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.6.3-blue?logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.0-38bdf8?logo=tailwind-css)
![Framer Motion](https://img.shields.io/badge/Motion-11.15-ff69b4)

## ✨ Features

- 🎨 **Modern 3D Design** - Beautiful animations and 3D effects using Framer Motion
- 📱 **Fully Responsive** - Works perfectly on mobile, tablet, and desktop
- ⚡ **Fast Performance** - Built with Vite for lightning-fast loading
- 🎯 **SEO Optimized** - Proper meta tags and semantic HTML
- 🌈 **Gradient Themes** - Eye-catching purple-pink gradient design
- 📧 **Contact Form** - Interactive contact section
- 💼 **Portfolio Showcase** - Dedicated sections for skills, experience, and projects

## 🚀 Quick Start

### Prerequisites

- Node.js 16+ installed
- VS Code (recommended)

### Installation

1. **Clone or download the project**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   ```
   http://localhost:5173
   ```

## 📁 Project Structure

```
farheen-portfolio/
├── src/
│   ├── App.tsx                    # Main app component
│   ├── main.tsx                   # App entry point
│   ├── components/
│   │   ├── Hero.tsx              # Hero/Landing section
│   │   ├── About.tsx             # About section
│   │   ├── Skills.tsx            # Skills showcase
│   │   ├── Experience.tsx        # Work experience
│   │   ├── Projects.tsx          # Project portfolio
│   │   ├── Contact.tsx           # Contact form
│   │   ├── Navigation.tsx        # Navigation bar
│   │   ├── Footer.tsx            # Footer section
│   │   ├── figma/
│   │   │   └── ImageWithFallback.tsx
│   │   └── ui/                   # Reusable UI components
│   └── styles/
│       └── globals.css           # Global styles
├── public/                       # Static files
├── index.html                    # HTML template
├── package.json                  # Dependencies
├── vite.config.ts               # Vite configuration
├── tsconfig.json                # TypeScript config
└── README.md                     # This file
```

## 🎨 Customization

### Update Personal Information

1. **Hero Section** - Edit `/src/components/Hero.tsx`
   - Name, title, bio
   - Contact links (GitHub, LinkedIn, Email, Phone)

2. **About Section** - Edit `/src/components/About.tsx`
   - Personal description
   - Career highlights

3. **Skills** - Edit `/src/components/Skills.tsx`
   - Add/remove technical skills
   - Update skill categories

4. **Experience** - Edit `/src/components/Experience.tsx`
   - Add your work history
   - Update achievements

5. **Projects** - Edit `/src/components/Projects.tsx`
   - Showcase your projects
   - Add project details and links

6. **Contact** - Edit `/src/components/Contact.tsx`
   - Update contact information
   - Customize contact form

### Change Theme Colors

Edit `/src/styles/globals.css` to modify the color scheme. Current theme uses:
- Purple (#9333ea)
- Pink (#ec4899)
- Slate (#0f172a)

## 🛠️ Available Scripts

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run linter
npm run lint
```

## 📦 Build for Production

```bash
# Build the project
npm run build

# The output will be in the 'dist' folder
```

## 🌐 Deployment

### Netlify (Recommended)

1. Build the project: `npm run build`
2. Upload the `dist` folder to [Netlify](https://netlify.com)

### Vercel

1. Install Vercel CLI: `npm install -g vercel`
2. Run: `vercel`

### GitHub Pages

1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add to package.json:
   ```json
   "homepage": "https://username.github.io/repo",
   "scripts": {
     "predeploy": "npm run build",
     "deploy": "gh-pages -d dist"
   }
   ```
3. Deploy: `npm run deploy`

## 🔧 Technologies Used

- **React 18** - UI Library
- **TypeScript** - Type Safety
- **Vite** - Build Tool
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **Lucide React** - Icons
- **ShadCN UI** - Component Library
- **Recharts** - Data Visualization

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📄 License

© 2024 Farheen Deshmukh. All rights reserved.

## 📧 Contact

- **Email**: farheendeshmukh38@gmail.com
- **Phone**: +91 8262029163
- **GitHub**: [github.com/farheendeshmukh](https://github.com/farheendeshmukh)
- **LinkedIn**: [linkedin.com/in/farheen-deshmukh](https://linkedin.com/in/farheen-deshmukh)

---

Made with ❤️ by Farheen Deshmukh
